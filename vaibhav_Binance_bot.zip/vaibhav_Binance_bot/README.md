
# Binance Futures Order Bot

A command-line bot that simulates placing Binance USDT-M Futures orders, including:
- Market Orders
- Limit Orders
- Advanced Orders (OCO, TWAP)

Note: This bot uses simulated/mock responses only, since I was unable to generate live API keys.
However, all logic is written to match Binance Futures API structure and can be activated by inserting real credentials.

## Project Structure

Vaibhav_binance_bot/
├── src/
│   ├── market_orders.py       # Simulated market orders
│   ├── limit_orders.py        # Simulated limit orders
│   └── advanced/
│       ├── oco.py             # Simulated OCO orders (TP + SL)
│       └── twap.py            # TWAP: time-split trading strategy
├── bot.log                    # Logs every action with timestamp
├── README.md                  # You’re reading this
└── report.pdf                 # Screenshots and explanations

## Requirements

- Python 3.8+
- Install dependencies:

pip install python-binance python-dotenv

Note: No API usage will occur without real keys, so you can still run the bot for testing.

## Setup (Optional – For Real API Usage)

1. Create a .env file in the root directory(I did'nt created as I was not able to generate the Binance Api key because of their restrictions):

BINANCE_API_KEY=your_key_here
BINANCE_API_SECRET=your_secret_here

2. Enable Futures access on Binance.

## Usage

Market Order

cd src
python market_orders.py BTCUSDT BUY 0.01

Limit Order

cd src
python limit_orders.py BTCUSDT SELL 0.01 58000

OCO Order

cd src/advanced
python oco.py BTCUSDT SELL 0.01 60000 55000

TWAP Order

cd src/advanced
python twap.py BTCUSDT BUY 0.05 5 2

This splits 0.05 BTC into 5 chunks, with a 2-second delay between each.

## Logs

All actions are saved to the bot.log file, including timestamps, errors, and order parameters.

## Notes

- Binance Futures API documentation was used to simulate real trading structure.
- All scripts include input validation and structured logging.
- No sensitive credentials are included.

## Author

Vaibhav Dubey
MCA Graduate
