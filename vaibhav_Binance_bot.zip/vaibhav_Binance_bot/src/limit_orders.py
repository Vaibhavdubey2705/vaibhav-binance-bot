# src/limit_orders.py

import sys
import logging

# Setup logging
logging.basicConfig(filename="bot.log", level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def validate_inputs(symbol, side, quantity, price):
    if not symbol.endswith("USDT"):
        raise ValueError("Only USDT pairs are supported.")
    if side.upper() not in ["BUY", "SELL"]:
        raise ValueError("Side must be BUY or SELL.")
    try:
        quantity = float(quantity)
        price = float(price)
        if quantity <= 0 or price <= 0:
            raise ValueError("Quantity and price must be positive.")
    except:
        raise ValueError("Quantity and price must be valid numbers.")
    return symbol.upper(), side.upper(), quantity, price

def place_limit_order(symbol, side, quantity, price):
    try:
        # MOCK response instead of real API
        mock_response = {
            "symbol": symbol,
            "side": side,
            "type": "LIMIT",
            "quantity": quantity,
            "price": price,
            "status": "NEW"
        }
        logging.info(f"Limit order simulated: {mock_response}")
        print("✅ Simulated Limit Order:", mock_response)
    except Exception as e:
        logging.error(f"Limit order failed: {e}")
        print("❌ Limit Order Error:", e)

if __name__ == "__main__":
    if len(sys.argv) != 5:
        print("Usage: python limit_orders.py <SYMBOL> <BUY/SELL> <QUANTITY> <PRICE>")
        sys.exit(1)

    try:
        symbol, side, quantity, price = validate_inputs(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
        place_limit_order(symbol, side, quantity, price)
    except Exception as err:
        logging.error(f"Validation error: {err}")
        print("❌ Error:", err)

