import sys
import logging

# Set up logging
logging.basicConfig(filename="bot.log", level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def validate_inputs(symbol, side, quantity):
    if not symbol.endswith("USDT"):
        raise ValueError("Only USDT pairs are supported.")
    if side.upper() not in ["BUY", "SELL"]:
        raise ValueError("Side must be BUY or SELL.")
    try:
        quantity = float(quantity)
        if quantity <= 0:
            raise ValueError("Quantity must be positive.")
    except:
        raise ValueError("Quantity must be a valid number.")
    return symbol.upper(), side.upper(), quantity

def place_market_order(symbol, side, quantity):
    try:
        # MOCK response instead of real API
        mock_response = {
            "symbol": symbol,
            "side": side,
            "type": "MARKET",
            "quantity": quantity,
            "status": "FILLED"
        }
        logging.info(f"Market order simulated: {mock_response}")
        print("✅ Simulated Market Order:", mock_response)
    except Exception as e:
        logging.error(f"Market order failed: {e}")
        print("❌ Market Order Error:", e)

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python market_orders.py <SYMBOL> <BUY/SELL> <QUANTITY>")
        sys.exit(1)

    try:
        symbol, side, quantity = validate_inputs(sys.argv[1], sys.argv[2], sys.argv[3])
        place_market_order(symbol, side, quantity)
    except Exception as err:
        logging.error(f"Validation error: {err}")
        print("❌ Error:", err)

