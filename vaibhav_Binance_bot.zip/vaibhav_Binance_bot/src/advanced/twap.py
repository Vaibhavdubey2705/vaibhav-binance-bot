# src/advanced/twap.py

import sys
import time
import logging

# Setup logging
logging.basicConfig(filename="../../bot.log", level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def validate_inputs(symbol, side, total_quantity, chunks, delay_seconds):
    if not symbol.endswith("USDT"):
        raise ValueError("Only USDT pairs are supported.")
    if side.upper() not in ["BUY", "SELL"]:
        raise ValueError("Side must be BUY or SELL.")
    try:
        total_quantity = float(total_quantity)
        chunks = int(chunks)
        delay_seconds = int(delay_seconds)
        if total_quantity <= 0 or chunks <= 0 or delay_seconds < 0:
            raise ValueError("All values must be valid positive numbers.")
    except:
        raise ValueError("Invalid format in quantity, chunks, or delay.")
    return symbol.upper(), side.upper(), total_quantity, chunks, delay_seconds

def simulate_twap(symbol, side, total_quantity, chunks, delay_seconds):
    quantity_per_chunk = round(total_quantity / chunks, 6)
    print(f"🚀 Starting TWAP simulation: {chunks} orders of {quantity_per_chunk} {symbol}, every {delay_seconds} sec")

    for i in range(1, chunks + 1):
        try:
            mock_order = {
                "symbol": symbol,
                "side": side,
                "quantity": quantity_per_chunk,
                "status": "FILLED",
                "chunk": i
            }
            logging.info(f"TWAP chunk {i}: {mock_order}")
            print(f"✅ Executed chunk {i}: {mock_order}")
            time.sleep(delay_seconds)
        except Exception as e:
            logging.error(f"TWAP chunk {i} failed: {e}")
            print(f"❌ Error in chunk {i}:", e)

if __name__ == "__main__":
    if len(sys.argv) != 6:
        print("Usage: python twap.py <SYMBOL> <BUY/SELL> <TOTAL_QUANTITY> <CHUNKS> <DELAY_SECONDS>")
        sys.exit(1)

    try:
        symbol, side, total_quantity, chunks, delay_seconds = validate_inputs(
            sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
        simulate_twap(symbol, side, total_quantity, chunks, delay_seconds)
    except Exception as err:
        logging.error(f"Validation error: {err}")
        print("❌ Error:", err)
