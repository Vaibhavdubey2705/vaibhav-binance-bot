import sys
import logging

# Setup logging
logging.basicConfig(filename="bot.log", level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def validate_inputs(symbol, side, quantity, take_profit_price, stop_loss_price):
    if not symbol.endswith("USDT"):
        raise ValueError("Only USDT pairs are supported.")
    if side.upper() not in ["BUY", "SELL"]:
        raise ValueError("Side must be BUY or SELL.")
    try:
        quantity = float(quantity)
        take_profit_price = float(take_profit_price)
        stop_loss_price = float(stop_loss_price)
        if quantity <= 0 or take_profit_price <= 0 or stop_loss_price <= 0:
            raise ValueError("All values must be positive numbers.")
    except:
        raise ValueError("Invalid number format.")
    return symbol.upper(), side.upper(), quantity, take_profit_price, stop_loss_price

def place_oco_order(symbol, side, quantity, take_profit_price, stop_loss_price):
    try:
        # MOCK simulated OCO logic
        mock_order = {
            "symbol": symbol,
            "side": side,
            "quantity": quantity,
            "take_profit_price": take_profit_price,
            "stop_loss_price": stop_loss_price,
            "status": "PENDING",
            "note": "Simulated OCO: TP & SL orders placed together"
        }
        logging.info(f"OCO order simulated: {mock_order}")
        print("✅ Simulated OCO Order:", mock_order)
    except Exception as e:
        logging.error(f"OCO order failed: {e}")
        print("❌ OCO Order Error:", e)

if __name__ == "__main__":
    if len(sys.argv) != 6:
        print("Usage: python oco.py <SYMBOL> <BUY/SELL> <QUANTITY> <TP_PRICE> <SL_PRICE>")
        sys.exit(1)

    try:
        symbol, side, quantity, tp_price, sl_price = validate_inputs(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
        place_oco_order(symbol, side, quantity, tp_price, sl_price)
    except Exception as err:
        logging.error(f"Validation error: {err}")
        print("❌ Error:", err)

